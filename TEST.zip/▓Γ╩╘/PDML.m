% function [estimated_source_doa,SnrEst]=MMEV(Signal,SnapNum,N,M,lmda)
% %input
%     %Signal                         Data received by the array
%     %SnapNum                        Snapshots number
%     %N                              The number of signal sources
%     %d                              Array element spacing
%     %M                              The number of received elements
%     %lmda                           Carrier wavelength
%     %P                              The subarray number
% %output
%     %estimated_source_doa           Estimated DOAs     
%     %SnrEst                         Estimated the eigenvalues ratio of signal to noise
% %%


Targ_Num=N;
r=lmda/(4*sin(pi/8));
RXX=(Signal*Signal.')/SnapNum;


% source_number=2; %信元数
% sensor_number=8; %阵元数
% N_x=1; %信号长度
% snapshot_number=N_x;%快拍数
% w=pi/4; %信号频率
% l=(2*pi*3e8)/w; %信号波长 
% d=0.5*l;%阵元间距
% snr=20;%信噪比
% source_doa=[10,-10];%两个信号的入射角度 
% A=exp(1j*(0:sensor_number-1)*d*2*pi.*(sin(source_doa*pi/180)/l)');%阵列流型
% s = zeros(length(source_number),N_x);
% for i = 1:length(source_doa) 
%     s(i,:)=sqrt(10.^(snr/10))*exp(1j*w*[0:N_x-1]);%仿真信号
% end 
% x=A'*s+(1/sqrt(2))*(randn(sensor_number,N_x)+1j*randn(sensor_number,N_x));%加了高斯白噪声后的阵列接收信号 
% R=x*x'/snapshot_number; 
searching_doa=-90:0.1:90;%线阵的搜索范围为-90~90度 
PDML1 =zeros(1,length(searching_doa)); 
for i=1:length(searching_doa) 
    A_theta=exp(-1j*(0:sensor_number-1)'*2*pi*d*sin(pi*searching_doa(i)/180)/l); 
    Pi_A_theta=A_theta*pinv(A_theta); oPi_A_theta=eye(size(Pi_A_theta))-Pi_A_theta; 
    PDML1(i)=trace(oPi_A_theta*RXX);
end 
figure(1);
plot(searching_doa,abs(10*log10(PDML1./max(PDML1))));
xlabel('DOAs/degree');
ylabel('trace(oPI A theta*R)/dB');
title('DML Algorithm for DOA');
grid on;