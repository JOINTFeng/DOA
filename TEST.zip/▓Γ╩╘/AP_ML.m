clc;
clearvars;
close all;
set(0,'defaultfigurecolor','w')
 
tic;
%% 时域快拍信号采样
% -1- 参数配置
% 基本参数
N = 512;       % 快拍点数
fs = 18e8;      % 系统采样率 单位：Hz
fc = 6e8;     % 载频       单位：Hz
c = 3e8;        % 光速       单位：m/s
lambda = c/fc;  % 波长       单位：m
 
% 信号 1 参数配置
B1 = 3e3;  % 信号1带宽 单位：Hz
T1 = N/fs;   % 信号1时宽 单位：s
K1 = B1/T1;  % 信号1调频斜率 单位：Hz/s
 
% 信号 2 参数配置
B2 = 100e3;  % 信号2带宽 单位：Hz
T2 = N/fs;   % 信号2时宽 单位：s
K2 = B2/T2;  % 信号2调频斜率 单位：Hz/s
 
 
% -2- 采样
t = (-N/2:N/2-1)/fs;        % 时间轴 
S1 = exp(1j*pi*K1*t.^2);    % 信号1采样 信源1 与信源2非相干
S2 = exp(1j*pi*K2*t.^2);    % 信号2采样 信源2 与信源1非相干
S = [S1;S1;S1];       % 相干信号 信号矩阵 （前2个信号相干）
MonteCarloNum=200; 
COV_COEFF_S1S2 = abs(cov(S1,S2)); % 信源1与信源2的相关性验证 
 
%% 阵列期望信号构建
% -1- 目标参数配置
Targ_Num = 3;            % 目标个数
theta = [-20,40,-120];      % 波达角度 单位：° 设定范围：[0 360)
theta=sort(theta); 
 
% -2- 阵列参数配置
M =16;             % 阵元个数
%r = 7*lambda/pi;    % 圆阵半径 单位：m
r=lambda/(4*sin(pi/M));
% -3- 计算方向矩阵
A = zeros(M,Targ_Num);
for i = 1:Targ_Num
    A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
end
 
% -4- 无噪阵列信号
Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);


for CarloNum=1:MonteCarloNum
Array_n=awgn(Array,20,'measured');
RXX=(Array_n*Array_n.')/N;

[V,D]=eig(RXX);
[D,I]=sort(diag(D));
D=fliplr(D');
g=sum(D(Targ_Num+1:end))/(M-Targ_Num);


K = 5; 
W = exp(1j*2*pi*((-K:K).')/M*(0:M-1));
J_v = zeros(2*K+1,1);
for i = -K:K
    J_v(i+K+1) = besselj(i,2*pi*r/lambda)*((1j)^i);
end
J_ = diag(J_v);
T = (inv(J_))*W/M;
% 矩阵转换
Y = T*Array_n;
 
% -STEP 2- 根据式(7)求得变换后的数据 Y 的协方差矩阵 RYY
TM=T*T.';

RYY = Y*Y.'/N;
RYY=RYY-g*g*eye(2*K+1,2*K+1)*TM;

   %确定初始值 
         th1=(-90:0.1:90)';
         th=th1/180*pi;
         q=zeros(1,Targ_Num);
         Q=zeros(1,length(th));
for          i=1:Targ_Num            % 其中N表示信号个数
             p1=sin(q);   
             p2=(0:(M-1))';
             p3=kron(p1,p2);
             p4=exp(-1*j*2*pi*dbc*p3);%第K(K>1)个信号的导向矢量
        for  k=1:length(th)
             pmu_a1=sin(th(k));
             pmu_a2=(0:(M-1))';
             pmu_a3=pmu_a1*pmu_a2; 
             pmu_a=exp(-1*j*2*pi*dbc*pmu_a3);
         if         i==1
                    P=pmu_a*pinv(pmu_a'*pmu_a)*pmu_a';   %初始信号
                    qk=trace(P*R);    %求矩阵的迹
                    Q(k)=qk;
         else   
                    pmu_b=zeros(M,i);
            for     m=1:(i-1)             %表示其前i-1个数
                    pmu_b(:,m)=p4(:,m);
            end
                    pmu_b(:,i)=pmu_a(:,1);   %表示a（i）
                    P=pmu_b*pinv(pmu_b'*pmu_b)*pmu_b';
                    qk=trace(P*R);
                    Q(k)=qk;
         end   
        end
                    b=max(Q);
         for        k=1:length(th)      
                if (b-Q(k))==0
                     c=k;
                    q(i)=th(c);
                end
         end
end






end