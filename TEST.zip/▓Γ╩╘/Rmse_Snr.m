%%
%{
    This program is used to describe the DOA estimation performance of the algorithm at different snapshots number. 
%}
clear,clc,close all;
M=32;
f0=6e8;
c=3e8;
SnapNum=256; 
source_doa=[-20 40 -120];
source_doa=sort(source_doa);
lmda=c/f0;
d=lmda/2;
w=2*pi*f0;
N=length(source_doa);
MonteCarloNum=2000;
SNR=linspace(0,20,10);
r=lmda/(4*sin(pi/8));


% % -3- 计算方向矩阵
% A = zeros(M,Targ_Num);
% for i = 1:Targ_Num
%     A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
% end
%  
% % -4- 无噪阵列信号
% Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);



for SnrNum=1:length(SNR)
  for CarloNum=1:MonteCarloNum
      A= [exp(1j*2*pi/lmda*r*cos(source_doa/180*pi-((0:M-1).')*2*pi/M))];
      Si=10.^((SNR(SnrNum)/2)/10)*exp(j*w*randn(N,1)*[0:SnapNum-1]);  
%coherent sources 
      Si(2,:)=Si(1,:)*exp(j*rand(1)*2*pi);                             
      Sig=A*Si;
      Signal=Sig+(1/sqrt(2))*(randn(M,SnapNum)+j*randn(M,SnapNum));        
% %------------------------------------FOSS METHOD--------------------------------------%
%       [ESPRIT_FOSS_doa,SnrEst_FOSS]=esprit_FOSS_function(Signal,SnapNum,K,d,M,lmda,SubarrayNum);
% %------------------------------------FBSS METHOD--------------------------------------%
%       [ESPRIT_FBSS_doa,SnrEst_FBSS]=esprit_FBSS_function(Signal,SnapNum,K,d,M,lmda,SubarrayNum);
% %----------------------------------ESPRIT_like METHOD---------------------------------%
%       [ESPRIT_like_doa,SnrEst_Like]=ESPRIT_like_function(Signal,SnapNum,K,d,M,lmda);
% %-----------------------------------FB_PTMR METHOD------------------------------------%         
%       [FB_PTMR_doa,SnrEst_FB]=FB_PTMR_function(Signal,SnapNum,K,d,M,lmda);
% %--------------------------------Multiple-Toeplitz METHOD-----------------------------%         
%       [Multiple_Toeplitz_doa,SnrEst_MO]=Multiple_Toeplitz_function(Signal,SnapNum,K,d,M,lmda);
%---------------------------------THE PROPOSED METHOD----------------------------------%

                                                            
      [MMEV_doa,SnrEst_MMEV]=MMEV(Signal,SnapNum,N,M,lmda);    
%% 
%Record results 
%       ESPRIT_FOSS_output(SnrNum,CarloNum,:)=ESPRIT_FOSS_doa';
%       ESPRIT_FBSS_output(SnrNum,CarloNum,:)=ESPRIT_FBSS_doa';
%       ESlike_output(SnrNum,CarloNum,:)=ESPRIT_like_doa';
%       Multiple_Toeplitz_output(SnrNum,CarloNum,:)=Multiple_Toeplitz_doa';
%       ESPRIT_MSB_output(SnrNum,CarloNum,:)=ESPRIT_MSB_doa';
        MMEV_output(SnrNum,CarloNum,:)=MMEV_doa';
      
%       ESPRIT_FOSS_SNR(SnrNum,CarloNum)=mean(10*log10(SnrEst_FOSS'));
%       ESPRIT_FBSS_SNR(SnrNum,CarloNum)=mean(10*log10(SnrEst_FBSS'))';
%       ESlike_SNR(SnrNum,CarloNum)=mean(10*log10(SnrEst_Like'));
%       Multiple_Toeplitz_SNR(SnrNum,CarloNum)=mean(10*log10(SnrEst_MO'));
%       ESPRIT_MSB_SNR(SnrNum,CarloNum)=mean(10*log10(SnrEst_MSB'));
        MMEV_SNR(SnrNum,CarloNum)=mean(10*log10(SnrEst_MMEV'));
  end %for CarloNum=1:MonteCarloNum
  SnrNum
end %for SnrNum=1:length(SNR)
%%
%Evaluate the eigenvalues ratio of signal to noise at different
%signal-to-noise ratios.(评估不同信噪比下信号与噪声的特征值比。)
% SNR_FOSS=mean(ESPRIT_FOSS_SNR,2);
% SNR_FBSS=mean(ESPRIT_FBSS_SNR,2);
% SNR_ESlike=mean(ESlike_SNR,2);
% SNR_Multiple=mean(Multiple_Toeplitz_SNR,2);
% SNR_MSB=mean(ESPRIT_MSB_SNR,2);
SNR_MMEV=mean(MMEV_SNR,2);
figure;
% plot(SNR,(SNR_FOSS),'-or');
% hold on
% plot(SNR,(SNR_FBSS),'-+g');
% hold on
% plot(SNR,(SNR_ESlike),'-*b');
% hold on
% plot(SNR,(SNR_FB),'-dm');
% hold on
% plot(SNR,(SNR_Multiple),'-sc');
% hold on
plot(SNR,(SNR_MMEV),'-dk');
%legend('FOSS','FBSS','ESPRIT-Like','FB-PTMR','MTOEP','Proposed Method');
legend('Proposed Method');
xlabel('SNR(dB)');
ylabel('Eigenvalues ratio of signal to noise(dB)');
grid on

%%
%Evaluate the DOA estimation performance at different signal-to-noise ratios.
%评估不同信噪比下的DOA估计性能。
Delat=2;
for SnrNum=1:length(SNR)
%%  
% %RMSE and POR based on FOSS ALGORITHM
%  for ii=1:length(source_doa)
%     a(ii,:)=squeeze(ESPRIT_FOSS_output(SnrNum,:,ii))-source_doa(ii);
%     ValidFOSS(ii)=length(find(abs(a(ii,:))<Delat));
%  end
%     d=sum(sum(a.^2));
%     ESPRIT_FOSS_RMS(SnrNum)=sqrt(d/(length(source_doa)*MonteCarloNum));
%     ValidLen=sum(ValidFOSS);
%     Probability_FOSS(SnrNum)=(ValidLen/(length(source_doa)*MonteCarloNum));
% %RMSE and POR based on FBSS ALGORITHM
%  for ii=1:length(source_doa)
%     a(ii,:)=squeeze(ESPRIT_FBSS_output(SnrNum,:,ii))-source_doa(ii);
%     ValidFBSS(ii)=length(find(abs(a(ii,:))<Delat));
%  end
%     d=sum(sum(a.^2));
%     ESPRIT_FBSS_RMS(SnrNum)=sqrt(d/(length(source_doa)*MonteCarloNum));
%     ValidLen=sum(ValidFBSS);
%     Probability_FBSS(SnrNum)=(ValidLen/(length(source_doa)*MonteCarloNum));
% 
% %RMSE and POR based on ESPRIT_like ALGORITHM
%  for ii=1:length(source_doa)
%     a(ii,:)=squeeze(ESlike_output(SnrNum,:,ii))-source_doa(ii);
%     Validlike(ii)=length(find(abs(a(ii,:))<Delat));
%  end
%     d=sum(sum(a.^2));
%     ESlike_RMS(SnrNum)=sqrt(d/(length(source_doa)*MonteCarloNum));
%     ValidLen=sum(Validlike);
%     Probability_Like(SnrNum)=(ValidLen/(length(source_doa)*MonteCarloNum));
%     
% %RMSE and POR based on FB_PTMR ALGORITHM
%  for ii=1:length(source_doa)
%     a(ii,:)=squeeze(FB_PTMR_output(SnrNum,:,ii))-source_doa(ii);
%     ValidFB_PTMR(ii)=length(find(abs(a(ii,:))<Delat));
%  end
%     d=sum(sum(a.^2));
%     FB_PTMR_RMS(SnrNum)=sqrt(d/(length(source_doa)*MonteCarloNum));
%     ValidLen=sum(ValidFB_PTMR);
%     Probability_FB_PTMR(SnrNum)=(ValidLen/(length(source_doa)*MonteCarloNum));    
%     
% %RMSE and POR based on Multiple_Toeplitz ALGORITHM
%  for ii=1:length(source_doa)
%     a(ii,:)=squeeze(Multiple_Toeplitz_output(SnrNum,:,ii))-source_doa(ii);
%     ValidToeplitz(ii)=length(find(abs(a(ii,:))<Delat));
%  end
%     d=sum(sum(a.^2));
%     Multiple_Toeplitz_RMS(SnrNum)=sqrt(d/(length(source_doa)*MonteCarloNum));    
%     ValidLen=sum(ValidToeplitz);
%     Probability_Multiple(SnrNum)=(ValidLen/(length(source_doa)*MonteCarloNum));
%RMSE and POR based on THE PROPOSED ALGORITHM
 for ii=1:length(source_doa)
    a(ii,:)=squeeze(MMEV_output(SnrNum,:,ii))-source_doa(ii);
    ValidMSB(ii)=length(find(abs(a(ii,:))<Delat));
 end
    d=sum(sum(a.^2));
    MMEV_RMS(SnrNum)=sqrt(d/(length(source_doa)*MonteCarloNum));
    ValidLen=sum(ValidMSB);
    Probability_MMEV(SnrNum)=(ValidLen/(length(source_doa)*MonteCarloNum));
end
%%
%Show the DOA estimation performance at different signal-to-noise ratios.
figure;
% plot(SNR,ESPRIT_FOSS_RMS,'-or');
% hold on
% plot(SNR,ESPRIT_FBSS_RMS,'-+g');
% hold on
% plot(SNR,ESlike_RMS,'-*b');
% hold on
% plot(SNR,FB_PTMR_RMS,'-dm');
% hold on
% plot(SNR,Multiple_Toeplitz_RMS,'-sc');
% hold on
plot(SNR,log(MMEV_RMS),'-dk');
%semilogy(SNR,MMEV_RMS);
%legend('FOSS','FBSS','ESPRIT-Like','FB-PTMR','MTOEP','Proposed Method');
legend('Proposed Method');
xlabel('SNR(dB)');
ylabel('RMSE(degree)');
grid on

%%
i=0;
figure;
% plot(SNR,Probability_FOSS,'-or');
% hold on
% plot(SNR,Probability_FBSS,'-+g');
% hold on
% plot(SNR,Probability_Like,'-*b');
% hold on
% plot(SNR,Probability_FB_PTMR,'-dm');
% hold on
% plot(SNR,Probability_Multiple,'-sc');
% hold on
plot(SNR,Probability_MMEV,'-dk');
%legend('FOSS','FBSS','ESPRIT-Like','FB-PTMR','MTOEP','Proposed Method');
legend('Proposed Method');
xlabel('SNR(dB)');
ylabel('Probability of resolution');
grid on
ylim([0 1]);