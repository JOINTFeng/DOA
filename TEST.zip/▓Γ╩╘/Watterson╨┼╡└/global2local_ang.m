clc;
clear;
%===============================参数设定===================================
M=8;%阵元数
% 基本参数
kp = 1000;       % 快拍点数
fs = 10e3;      % 系统采样率 单位：
f= 6e6;
fc = 6e6;     % 载频       单位：Hz
c = 3e8;        % 光速       单位：m/s
lamda = c/fc;  % 波长       单位：m 
r=lamda/(4*sin(pi/8));%不模糊最大阵列半径
fw=[200 203];%信号源方位角度0--360
fy=[8.5 28];%信号源俯仰角度0--60
fd=[40.7 34.5];%信号源极化幅度特性0--90
xw=[-20 -90];%信号源极化相位特性0--360
Num=length(fw);%信号源数
radian=pi/180;%弧度单位
rfw=fw*radian;%方位角弧度
rfy=fy*radian;%俯仰角弧度
rfd=fd*radian;%信号源极化幅度特性弧度
rxw=xw*radian;%信号源极化相位特性弧度
snr=5;      %信噪比
step_fw=0.5;%方位角步进
step_fy=0.5;%俯仰角步进


 
% 信号 1 参数配置
B1 = 2e3;  % 信号1带宽 单位：Hz
T1 = kp/fs;   % 信号1时宽 单位：s
K1 = B1/T1;  % 信号1调频斜率 单位：Hz/s
 
% 信号 2 参数配置
B2 = 2e3;  % 信号2带宽 单位：Hz
T2 = kp/fs;   % 信号2时宽 单位：s
K2 = B2/T2;  % 信号2调频斜率 单位：Hz/s
 
 
% -2- 采样
Ts=1/fs;%采样间隔
shiyan=[1.2 2 2.6]*1e-3;%时延s
delay=round(shiyan/Ts);% 将延时转换为延时位数，四舍五入为最近的小数

n1=2;
phi=2*pi*rand(1,n1);           %产生n条路径的相位向量
t = (-kp/2:kp/2-1)/fs;        % 时间轴 
%S1 = exp(1j*phi(1)+1j*pi*K1*t.^2);    % 信号1采样 信源1 与信源2非相干
S1 = exp(1j*pi*K1*t.^2);
%S1 = [zeros(1,delay(1)) S1(1:end-delay(1))];
%S2 = exp(1j*phi(2)+1j*pi*K2*t.^2);    % 信号2采样 信源2 与信源1非相干
phi_offset = pi;
S2 = exp(1j*pi*K2*t.^2+phi_offset);
%S2 = [zeros(1,delay(2)) S2(1:end-delay(2))];
S3 = exp(1j*pi*K1*t.^2);    % 信号3采样 信源3 与信源1,2非相干
%S3 = [zeros(1,delay(3)) S3(1:end-delay(3))];
%S = [S1;S2];       %信号矩阵


fs = 12e3;            % 采样频率
T = 1;                % 信号持续时间
%t = 0:1/fs:T-1/fs;    % 时间向量
t = (-kp/2:kp/2-1)/fs;

f1 = 6e3;              % 正弦波频率
f2 = 6e3-5;
phi1 = 0;             % 相位1
phi2 = phi1 + pi/8;     % 相位2，相差180度

% 用exp形式表示两个相位相差180度的正弦波
sin_wave1 = exp(1j * (2 * pi * f1 * t + phi1));
sin_wave2 = 3*exp(1j * (2 * pi * f2 * t + phi2));
s=sin_wave1+sin_wave2;

S = [sin_wave1;sin_wave2];       %信号矩阵
% % 绘制两个正弦波及其叠加
% figure;
% subplot(3, 1, 1);
% plot(t, real(sin_wave1), 'r', 'LineWidth', 2);
% title('Sin Wave 1');
% 
% subplot(3, 1, 2);
% plot(t, real(sin_wave2), 'b', 'LineWidth', 2);
% title('Sin Wave 2');
% 
% subplot(3, 1, 3);
% plot(t, real(s), 'g', 'LineWidth', 2);
% title('Sum of Sin Waves');
% 
% xlabel('Time (s)');
% ylabel('Amplitude');
% 
% sgtitle('Two Sin Waves with 180° Phase Difference (Exponential Form)');

%=============================空间导向矢量=================================
delay=ones(M,Num);%定义延迟矩阵
As=ones(M,Num);%定义阵列流型矢量矩阵
for m=1:M      %阵列流型矢量矩阵赋值
    for n=1:Num  
        delay(m,n)=(cos(rfw(n)-(m-1)*pi/4)*r*sin(rfy(n)))/c;%列向量延迟赋值
        As(m,n)=exp((-2*pi*f*1i).*delay(m,n));%阵列流型矢量赋值
    end      
end
as=[exp(-1j*(-1+(1+1)*rand(M,1))),exp(-1j*(-1+(1+1)*rand(M,1)))];
%As=As.*as;
A=ones(6*M,Num);%定义空间极化导向矢量
for n=1:Num   %空间极化导向矢量赋值
wfw=rfw(n);
wfy=rfy(n);
V=[-sin(wfw) cos(wfw)*cos(wfy);cos(wfw) cos(wfy)*sin(wfw);0 -sin(wfy);cos(wfw)*cos(wfy) sin(wfw);cos(wfy)*sin(wfw) -cos(wfw);-sin(wfy) 0];%导向矢量
wfd=rfd(n);
wxw=rxw(n);
E=[cos(wfd);sin(wfd)*exp(1i*wxw)];%定义极化矢量
Ap=V*E;%极化导向矢量
A(:,n)=kron(As(:,n),Ap);%柯洛内特积
end


%===============================求协方差矩阵特征值================================
X=A*S;   %接受信号模型
X=awgn(X,snr,'measured');

% X1=X(1:8,:);
% X2=X(9:16,:);
% X3=X(17:24,:);
% X4=X(25:32,:);
% X5=X(33:40,:);
% X6=X(41:48,:);





num_i=length(fw);
Rx_j = X*X'/kp;                %计算信号模型的协方差矩阵
% RX1=X1*X1'/kp;
% RX2=X2*X2'/kp;
% RX3=X3*X3'/kp;
% RX4=X4*X4'/kp;
% RX5=X5*X5'/kp;
% RX6=X6*X6'/kp;
% Rx_j=(RX1+RX2+RX3+RX4+RX5+RX6)/6;


[Vn,D] = eig(Rx_j);              %特征值分解，[Vn,D]=eig(Rxx)返回特征值的对角矩阵D和矩阵En，其列是对应的右特征向量，使得 Rx_j*Vn = Vn*D。
EVA = diag(D)';                  %EVA = diag(D) 返回包含主对角线上向量 D 的元素的对角矩阵。
[EVA,I] = sort(EVA);             %[EVB,I] = sort(EVA)还会为按升序对EVA的元素进行排序返回一个索引向量的集合。I的大小与EVA的大小相同，它描述了EVA的元素沿已排序的维度在EVB中的排列情况。例如，如果EVA是一个向量，则EVB=EVA(I)。
EVA = fliplr(EVA);               %左右反转，从大到小排序
Vn = fliplr(Vn(:,I));            %对应特征向量排序
Vn=Vn(:,num_i+1:M);               %噪声子空间








% X_zz=X';  %转置
% Rx=X(:,1)*X_zz(1,:); %协方差矩阵
% length_Rx=size(Rx,1);
% Rx_p=zeros(length_Rx,length_Rx);%定义协方差矩阵的和
% for m=1:kp   %协方差矩阵求和
%     Rx=X(:,m)*X_zz(m,:);  %求一次的协方差矩阵  
%     Rx_p=Rx_p+Rx;      %协方差矩阵求和
% end
% Rx_j=Rx_p/kp;  %求协方差矩阵除以快拍数的均值
% y=size(Rx_j,1);%协方差矩阵的行数
% P=eye(y);   %产生y阶单位阵
% %计算A中上半对角线零的个数，确定是否跳出循环
% for x=1:1:1000     %1000为循环足够大的次数
% q=0;
%     for n=1:1:y-1      %按照论文方法进行循环
%         for m=n+1:1:y  
%             if round(Rx_j(n,m))==0%判断A（n,m）是否为零
%                 q=q+1;
%             end
% Y = eye(y);        %生成一个y阶对角矩阵，为U（p，k）做准备
% B=Rx_j([n m],[n m]);   %取主子阵
% b1=B(1,2);           
% b2=B(1,1);
% b3=B(2,2);
% t1=sqrt((real(b1)^2)+(imag(b1)^2));    %分子
% t2=real(b1)-imag(b1)*1i;           %分母
% phi=asin(imag(b1)/t2);          %求角phi，未用到
% tan=(2*t1/(b2-b3));
% thet=atan(tan);            %求角2*theta
% theta=thet/2;
% Y(n,n)=cos(theta);
% Y(n,m)=-sin(theta);
% Y(m,n)=sin(theta)*(t2/t1);
% Y(m,m)=cos(theta)*(t2/t1); %Y即U（p,k）
% dds=Y'*Rx_j;
% dds1=dds*Y;
% Rx_j=Y'*Rx_j*Y;     %An
% P=P*Y;          %特征向量
%        end
%     end
%  if (2*q-y*y+y)==0
%      break;       %通过q值来判断是否跳出循环
%  end
% end
% T=real(diag(Rx_j));%取协方差矩阵的特征值
% [T_sort,ss_T]=sort(T,'descend'); %对特征值进行排序并返回结果
% %====================信源数估计，用到特征值和阵元数=========================
% ld=0:7;
% MDL=0:7;
%  for n=0:(M-1)
%      a=0;
%      b=1;
%  for m=(n+1):M
%     a=a+T_sort(m);
%     b=b*T_sort(m); 
%  end
%  aa1=(1/(M-n))*a;
%  aa2=b^(1/(M-n));
%  ld(n+1)=((1/(M-n))*a)/(b^(1/(M-n)));
%  MDL(n+1)=kp*(M-n)*log(ld(n+1))+0.5*n*(2*M-n)*log(kp);
%  end
% [q1,hq]=min(MDL);
% num_i=hq-1;   %信号个数
% z=P(:,ss_T);  %特征向量排序
% Vn=z(:,num_i+1:M);%噪声子空间
%==================================谱峰部分================================
fw_s=0:step_fw:360; %方位加步长
fy_s=0:step_fy:90;  %俯仰加步长
rfws=fw_s*radian;  
rfys=fy_s*radian;
Nu=length(fw_s);
Nuu=length(fy_s);
delay_s=ones(M,Nu*Nuu);%定义位置信息延迟变量
As_s=ones(M,Nu*Nuu);   %定义阵列流型矢量变量
DOA_d=ones(Nu,Nuu); %定义信号变量与噪声矩阵乘积的函数
for n=1:Nu                 %方位角
    for m=1:Nuu         %俯仰角
        for k=1:M    
        delay_s(k,(n-1)*Nuu+m)= (cos(rfws(n)-(k-1)*pi/4)*r*sin(rfys(m)))/c;%定义列向量延迟
        As_s(k,(n-1)*Nuu+m)=exp((-2*pi*f*1i).*delay_s(k,(n-1)*Nuu+m));%定义A列向量
        end
        wfw=rfws(n);
        wfy=rfys(m);
        V_s=[-sin(wfw) cos(wfw)*cos(wfy);cos(wfw) cos(wfy)*sin(wfw);0 -sin(wfy);cos(wfw)*cos(wfy) sin(wfw);cos(wfy)*sin(wfw) -cos(wfw);-sin(wfy) 0];%导向矢量变量
        V_s=V_s*[cos(rfd(2));sin(rfd(2))*exp(1i*rxw(2))];
        A_s=kron(As_s(:,(n-1)*Nuu+m),V_s);%空间导向矢量
        G=A_s'*(Vn*Vn')*A_s;%空间导向矢量与噪声子空间的乘
        DOA_d(n,m)=real(det(G));%DOA参数估计函数的倒数
    end      
end
DOA=1./DOA_d;%DOA估计参数函数
SPmax1=max(max(DOA));
SP1=10*log10(DOA/SPmax1);
DOA_p=imregionalmax(DOA);%DOA参数峰值矩阵
figure(1);
mesh(fy_s,fw_s,SP1);%DOA估计图
xlabel('俯仰角/°');ylabel('方向角/°');zlabel('空间谱/dB');
%===================================谱峰搜索===============================
[fw_p,fy_p]=find(DOA_p==1);%将DOA中峰值的点坐标返回至o,p矩阵中
DOA_max=zeros(1,length(fw_p));%定义DOA估计中峰值数组
for n=1:length(fw_p)%将峰值顺序输入DOA_max中
        DOA_max(1,n)=DOA(fw_p(n),fy_p(n));
end
fw_j=zeros(1,num_i);%定义方位角结果
fy_j=zeros(1,num_i);%定义俯仰角结果
for n=1:num_i       
    [mem,pos]=max(DOA_max);%将峰值的最大值位置输入数组
    fw_j(1,n)=(fw_p(pos)-1)*step_fw;%按照位置确定方位角
    fy_j(1,n)=(fy_p(pos)-1)*step_fy;%确定俯仰角
    DOA_max(pos)=0;%定义该峰值为0，以便循环寻找最大值
end
fw_j %#ok<NOPTS>
fy_j %#ok<NOPTS>
rfw_j=fw_j*radian;
rfy_j=fy_j*radian; 
%=================================极化参数估计=============================
fd_j=1:num_i;
xw_j=1:num_i;
fd_jr=1:num_i;
xw_jr=1:num_i;
for k=1:num_i
delay_j=zeros(M,1);%定义极化信息估计时的延迟
As_j=zeros(M,1);%定义极化信息估计时的导向矢量
for m=1:M    %导向矢量赋值
    delay_j(m,1)= (cos(rfw_j(k)-(m-1)*pi/4)*r*sin(rfy_j(k)))/c ;  %定义列向量延迟
    As_j(m,1)=exp((-2*pi*f*1i).*delay_j(m,1));     %定义A列向量
end
wfw_j=rfw_j(k);
wfy_j=rfy_j(k);
%V_j=[-sin(wfw_j) cos(wfw_j)*cos(wfy_j);cos(wfw_j) cos(wfy_j)*sin(wfw_j)];
V_j=[-sin(wfw_j) cos(wfw_j)*cos(wfy_j);cos(wfw_j) cos(wfy_j)*sin(wfw_j);0 -sin(wfy_j);cos(wfw_j)*cos(wfy_j) sin(wfw_j);cos(wfy_j)*sin(wfw_j) -cos(wfw_j);-sin(wfy_j) 0];
A_j=kron(As_j(:,1),V_j);%空间极化导向矢量
G_j=A_j'*(Vn*Vn')*A_j;%空间导向矢量与噪声子空间的乘
y_j=size(G_j,1);%协方差矩阵的行数
P_j=eye(y_j);   %产生y阶单位阵
%计算A中上半对角线零的个数，确定是否跳出循环
for x=1:1:1000     %100为循环足够大的次数
q=0;
    for n=1:1:y_j-1      %按照论文方法进行循环
        for m=n+1:1:y_j  
            if round(G_j(n,m))==0%判断A（n,m）是否为零
                q=q+1;
            end
Y = eye(y_j);        %生成一个y阶对角矩阵，为U（p，k）做准备
B_j=G_j([n m],[n m]);   %取主子阵
b1=B_j(1,2);           
b2=B_j(1,1);
b3=B_j(2,2);
t1=sqrt((real(b1)^2)+(imag(b1)^2));    %分子
t2=real(b1)-imag(b1)*1i;           %分母
phi=asin(imag(b1)/t2);          %求角phi，未用到
tan=(2*t1/(b2-b3));
thet=atan(tan);            %求角2*theta
theta=thet/2;
Y(n,n)=cos(theta);
Y(n,m)=-sin(theta);
Y(m,n)=sin(theta)*(t2/t1);
Y(m,m)=cos(theta)*(t2/t1); %Y即U（p,k）
dds=Y'*G_j;
dds1=dds*Y;
G_j=Y'*G_j*Y;     %An
P_j=P_j*Y;
       end
    end
 if (2*q-y_j*y_j+y_j)==0
     break;       %通过q值来判断是否跳出循环
 end
end
T_j=real(diag(G_j));
[T_sort_j,ss_j]=sort(T_j,'descend'); %对特征值进行排序并返回结果
E_j=P_j(:,ss_j(size(ss_j,1)));%噪声子空间
fd_jr(k)=atan(abs(E_j(2,1)/E_j(1,1)));%计算极化幅度信息
fd_j(k)=fd_jr(k)/radian;
xw_jr(k)=angle(E_j(2,1)/E_j(1,1));%计算极化相位信息
xw_j(k)=xw_jr(k)/radian;
end
fd_j %#ok<NOPTS>
xw_j %#ok<NOPTS>



delay=ones(M,Num);%定义延迟矩阵
As=ones(M,Num);%定义阵列流型矢量矩阵
for m=1:M      %阵列流型矢量矩阵赋值
    for n=1:Num  
        delay(m,n)=(cos(rfw(n)-2*(m-1)*pi/M)*r*sin(rfy(n)))/c;%列向量延迟赋值
        As(m,n)=exp((2*pi*f*1i).*delay(m,n));%阵列流型矢量赋值
    end      
end


%=============================空间导向矢量=================================
delay=ones(M,Num);%定义延迟矩阵
As=ones(M,Num);%定义阵列流型矢量矩阵
for m=1:M      %阵列流型矢量矩阵赋值
    for n=1:Num  
        delay(m,n)=(cos(rfw(n)-2*(m-1)*pi/M)*r*sin(rfy(n)))/c;%列向量延迟赋值
        As(m,n)=exp((2*pi*f*1i).*delay(m,n));%阵列流型矢量赋值
    end      
end
%As=As.*as;


%===============================求协方差矩阵特征值================================
X=As*S;
X=awgn(X,snr,'measured');
Rx_j = X*X'/kp;                %计算信号模型的协方差矩阵
[Vn,D] = eig(Rx_j);              %特征值分解，[Vn,D]=eig(Rxx)返回特征值的对角矩阵D和矩阵En，其列是对应的右特征向量，使得 Rx_j*Vn = Vn*D。
EVA = diag(D)';                  %EVA = diag(D) 返回包含主对角线上向量 D 的元素的对角矩阵。
[EVA,I] = sort(EVA);             %[EVB,I] = sort(EVA)还会为按升序对EVA的元素进行排序返回一个索引向量的集合。I的大小与EVA的大小相同，它描述了EVA的元素沿已排序的维度在EVB中的排列情况。例如，如果EVA是一个向量，则EVB=EVA(I)。
EVA = fliplr(EVA);               %左右反转，从大到小排序
Vn = fliplr(Vn(:,I));            %对应特征向量排序
Vn2=Vn(:,num_i+1:M);               %噪声子空间

%==================================谱峰部分================================
fw_s=0:step_fw:360; %方位加步长
fy_s=0:step_fy:90;  %俯仰加步长
rfws=fw_s*radian;  
rfys=fy_s*radian;
Nu=length(fw_s);
Nuu=length(fy_s);
delay_s=ones(M,Nu*Nuu);%定义位置信息延迟变量
As_s=ones(M,Nu*Nuu);   %定义阵列流型矢量变量
DOA_d=ones(Nu,Nuu); %定义信号变量与噪声矩阵乘积的函数
 for n=1:Nu              %方位角
    for m=1:Nuu         %俯仰角
            for k=1:M    
            delay_s(k,(n-1)*Nuu+m)= (cos(rfws(n)-2*(k-1)*pi/M)*r*sin(rfys(m)))/c;%定义列向量延迟
            As_s(k,(n-1)*Nuu+m)=exp((2*pi*f*1i).*delay_s(k,(n-1)*Nuu+m));%定义A列向量
            end
            A_s=kron(As_s(:,(n-1)*Nuu+m),1);%空间导向矢量;
            G=A_s'*(Vn2*Vn2')*A_s;%空间导向矢量与噪声子空间的乘
            %DOA_d(n,m)=1/G;
            DOA_d(n,m)=real(det(G));%DOA参数估计函数的倒数
     end      
 end

DOA=1./DOA_d;%DOA估计参数函数
SPmax=max(max(DOA));
SP=10*log10(DOA/SPmax);
DOA_p=imregionalmax(DOA);%DOA参数峰值矩阵
figure(2);
mesh(fy_s,fw_s,SP);%DOA估计图



% DOA=1./abs(DOA_d);%DOA估计参数函数
% SPmax=max(max(DOA));
% SP=10*log10(DOA/SPmax);
% DOA_p=imregionalmax(DOA);%DOA参数峰值矩阵

%mesh(fy_s,fw_s,SP);%DOA估计图
% mesh(fy_s,fw_s,DOA);%DOA估计图
xlabel('俯仰角/°');ylabel('方向角/°');zlabel('空间谱/dB');
%===================================谱峰搜索===============================
[fw_p,fy_p]=find(DOA_p==1);%将DOA中峰值的点坐标返回至o,p矩阵中
DOA_max=zeros(1,length(fw_p));%定义DOA估计中峰值数组
for n=1:length(fw_p)%将峰值顺序输入DOA_max中
        DOA_max(1,n)=DOA(fw_p(n),fy_p(n));
end
fw_j1=zeros(1,num_i);%定义方位角结果
fy_j1=zeros(1,num_i);%定义俯仰角结果
for n=1:num_i       
    [mem,pos]=max(DOA_max);%将峰值的最大值位置输入数组
    fw_j1(1,n)=(fw_p(pos)-1)*step_fw;%按照位置确定方位角
    fy_j1(1,n)=(fy_p(pos)-1)*step_fy;%确定俯仰角
    DOA_max(pos)=0;%定义该峰值为0，以便循环寻找最大值
end
fw_j1 %#ok<NOPTS>
fy_j1 %#ok<NOPTS>