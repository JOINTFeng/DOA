function[r,x,y]=raychan(n)   %n为路径数 x,y分别为叠加后信号实部和虚部，r为信号包络
t=1;  v=50;  lamda=1/3;   %t，v，lamda初始化一个值
alpha=rand(1,n);           %产生n条路径的幅度向量
phi=2*pi*rand(1,n);        %产生n条路径的相位向量
theta=2*pi*rand(1,n);       %产生n条路径的多普勒频移的角度向量
s=alpha.*(exp(1j.*(phi+2*pi*v*t/lamda*cos(theta))))*ones(1,n)';  %s为n条路径的叠加
x=real(s);
y=imag(s);
r=sqrt(x^2+y^2);
end
