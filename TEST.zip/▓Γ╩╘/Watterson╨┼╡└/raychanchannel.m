clc; 
clear;
N=10000;         %N代表获取的r的个数 
r=zeros(1,N);      %r初始化为零
n1=2;            %n为路径数
x=r; y=r; theta=r;   %x，y，theta初始化为零
for i=1:N         %该循环产生N个r，N个theta，N个x，N个y
    [r(i),x(i),y(i)]=raychan(n1);
end
sigma=sqrt(var(x));   %计算标准差sigma
index=[0:0.01:max(r)];     %index为横坐标的取值范围，相当于规定了r/sigma的坐标

p=histcounts(r,index);      %p为r在index规定的区间里的统计个数
P=zeros(1,length(p));   %P用来计算累加的区间统计，在概率中相当于F（x），先初始化，然后循环求值
for i=1:length(p)
    for j=1:i
    P(i)=P(i)+p(j);
    end
end
P=P/N;                    %除以总数N得到概率
index=index(1:end-1);
poly_c=polyfit(index,P,9);     %用9阶多项式拟合P（index）,得到多项式系数行列式poly_c
pd=polyder(poly_c);         % 多项式微分，即对P(index)微分，相当于求f（x）概率密度
p_practice=polyval(pd,index);    %求出index对应的多项式函数值p_practice
p_theory=index/sigma^2.*exp(-index.^2/(2*sigma^2));        %求出index对应的p_theory值                                              

%画出r的实际和理论概率密度函数图
plot(index,p_practice,'b-',index,p_theory,'r-');
legend('Practical','Theoretical');
title('Amplitude Practical versus Theoretical');
xlabel('r/\sigma');
ylabel('P(r)');
axis([0 4 0 0.8]);
grid on;
