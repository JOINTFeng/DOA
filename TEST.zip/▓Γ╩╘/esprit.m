%% 仿真ESPRIT算法测向
% 参数 :
% 阵元数：8
% 入射信号角度：[-20 0 30]
% 信噪比：10
% 信源数：3
% 快拍数：500
%日期 :2023.6.19 作者：sxl 参考《空间谱估计理论与算法--王永良》
%% 生成数据，三个信号源
clc
clear
close all
m = 8;  %阵元数
N = 3;  %信源数为3
L = 500;%假设快拍数为500
SNR = 10;%信噪比，根据信噪比计算噪声大小
Noise1 = 1/(10^(SNR/20)).*randn(m-1,L);%根据信噪比生成噪声
Noise2 = 1/(10^(SNR/20)).*randn(m-1,L);%根据信噪比生成噪声
S = randn(N,L)+1j*randn(N,L);%随机产生N个快拍数为L的独立信源
theta = [-20,0,30];%假设三个信号源的入射角度分别为-20，0，30
A1 = exp(1j*pi.*(0:m-2)'*sin(theta/180*pi));%子阵A1的阵列流型
A2 = exp(1j*pi.*(0:m-2)'*sin(theta/180*pi))*diag(exp(1j*pi*sin(theta/180*pi)));%子阵A2的阵列流型
X1 = A1*S+Noise1; %第一个子阵的接收数据
X2 = A2*S+Noise2; %第二个子阵的接收数据
X =[X1;X2]; %两个子阵数据合并处理
R = X*X'; %计算协方差矩阵

%% 最小二乘法求解
[U, lamada_i]=eig(R);%特征分解
Us = U(:,2*(m-1)-N+1:2*(m-1));%信号子空间
PHI_LS = Us(1:m-1,:)'*Us(m:2*m-2,:)/(Us(1:m-1,:)'*Us(1:m-1,:));%最小二乘的解
[Vpsi, Dpsi]=eig(PHI_LS);%进行特征分解
theta_LS=asin(angle(diag(Dpsi))/pi)*180/pi;%反解出波达角
theta_LS = sort(theta_LS);%重新排序

%% 总体最小二乘法求解
Us1 = Us(1:m-1,:);%第一个子阵张成的信号空间
Us2 = Us(m:2*m-2,:);%第二个子阵张成的信号空间
Us12 = [Us1 Us2];
Mat = Us12'*Us12;
[E, lamada_k]=eig(Mat);
E11 = E(1:N,1:N);
E21 = E(N+1:2*N,1:N);
PHI_TLS = -E11/E21;
[VER,lamad_est] = eig(PHI_TLS);
theta_TLS = asin(angle(diag(lamad_est))/pi)*180/pi;
theta_TLS = sort(theta_TLS);
disp('真实值  LS_ESPRIT估计值  TLS_ESPRIT估计值');
disp([theta' theta_LS  theta_TLS]);




