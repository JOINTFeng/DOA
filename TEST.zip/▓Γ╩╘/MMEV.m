function [estimated_source_doa,SnrEst]=MMEV(Signal,SnapNum,N,M,lmda)
%input
    %Signal                         Data received by the array
    %SnapNum                        Snapshots number
    %N                              The number of signal sources
    %d                              Array element spacing
    %M                              The number of received elements
    %lmda                           Carrier wavelength
    %P                              The subarray number
%output
    %estimated_source_doa           Estimated DOAs     
    %SnrEst                         Estimated the eigenvalues ratio of signal to noise
%%

%% 阵列期望信号构建
% % -1- 目标参数配置
% Targ_Num = 3;            % 目标个数
% theta = [-20,40,-120];      % 波达角度 单位：° 设定范围：[0 360)
%  
%  
% % -2- 阵列参数配置
% M =16;             % 阵元个数
% d_lambda = 1/2;     % 阵元间距/波长
% %r = 7*lambda/pi;    % 圆阵半径 单位：m
% r=lambda/(4*sin(pi/8));
% % -3- 计算方向矩阵
% A = zeros(M,Targ_Num);
% for i = 1:Targ_Num
%     A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
% end
%  
% % -4- 无噪阵列信号
% Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);
%  
% % -5- 加噪
% 
% SNR=0:20; 
% for iii=1:length(SNR) 
% sigma2_n = .1;      % 高斯白噪声的功率 σ平方
% % rng(1);
% noise = sqrt(sigma2_n/2)*randn(M,N)+1j*sqrt(sigma2_n/2)*randn(M,N); % 复高斯噪声矩阵
% Array_n=awgn(Array,(iii-1),'measured');
% %Array_n = Array + noise;
Targ_Num=N;
r=lmda/(4*sin(pi/8));
RXX=(Signal*Signal.')/SnapNum;
%e=eig(RXX);

[U1,S,V1]=svd(RXX);                                                     
a=diag(S);
SnrEst=((a(1:N))./mean(a(N+1)));


[V,D]=eig(RXX);
[D,I]=sort(diag(D));
D=fliplr(D');
g=sum(D(Targ_Num+1:end))/(M-Targ_Num);



%% 基于MME算法+Root-MUSIC算法的DOA估计
% 主要参考文献[1]2.2节
% -STEP 1- 由式(4)对圆阵数据 X 进行模式空间变换得到 (2K+1) 维虚拟均匀线阵数据 Y
% 构建矩阵T
%K = floor(2*pi*r/lambda);
K1 = 5; 
W = exp(1j*2*pi*((-K1:K1).')/M*(0:M-1));
J_v = zeros(2*K1+1,1);
for i = -K1:K1
    J_v(i+K1+1) = besselj(i,2*pi*r/lmda)*((1j)^i);
end
J_ = diag(J_v);
T = (inv(J_))*W/M;
% 矩阵转换
Y = T*Signal;
 
% -STEP 2- 根据式(7)求得变换后的数据 Y 的协方差矩阵 RYY
TM=T*T.';

RYY = Y*Y'/SnapNum;
RYY=RYY-g*g*eye(2*K1+1,2*K1+1)*TM;
% -STEP 3- 对 RYY 特征分解得到其最大特征矢量 v
% 对协方差矩阵进行特征值分解
[V,eigenvalue] = eig(RYY);        
% 特征值按降序排列
eigenvalue = diag(eigenvalue);                                  % 取特征值 转为列向量
[eigen_sort,eigen_index] = sort(abs(eigenvalue),'descend');     % 特征值降序排列
% 提取最大特征矢量v
v = V(:,eigen_index(1)); 
% -STEP 4- 根据式(8)构造新的矩阵 E
E = zeros(K1+1,K1+1);
for i = 1:K1+1
    E(i,:) = v(K1+i:-1:i);
end
 
% -STEP 5- 对 E 特征分解得到噪声子空间 UW
% 对 E 矩阵进行特征值分解
[V2,eigenvalue2] = eig(E);        
 
% 特征值按降序排列
eigenvalue2 = diag(eigenvalue2);                                   % 取特征值 转为列向量
[eigen_sort2,eigen_index2] = sort(abs(eigenvalue2),'descend');     % 特征值降序排列
D = Targ_Num;                                                      % 信源数目 
 
% 构造噪声子空间
Un = V2(:,eigen_index2(D+1:end));
Gn = Un*Un';
%%%Root-MUSIC%%%
MM=2*K1+1;
a = zeros(2*MM-1,1);
for j=-(MM-1):(MM-1)
a(MM+j) = sum( diag(Gn,j) );
end
ra=roots([a]);
rb=ra(abs(ra)<1);
% 选取最接近单位圆的n个根
[dumm,I]=sort(abs(abs(rb)-1));
degrad=pi/180;
w=angle(rb(I(1:D))); 
fi=-w/degrad;
estimated_source_doa=sort(fi);