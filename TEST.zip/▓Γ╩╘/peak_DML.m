%==============角度搜索程序=============

%  输出前N个峰对应的角度,按角度的从小到大排列
%
% out=peak_seek(pmusic,p_index,N)
%
%    pmusic   <- 频谱向量
%    p_index  <- 对应频谱向量的角度
%    N        <- 前N个峰
%

%copyright by kily 2008

 function out=peak_DML(pmusic,p_index,N)
 jj=0;
 mm=1;
 temp=pmusic(1);
 peak=[];
 index=[];
 for ii=2:length(pmusic)
     if temp<pmusic(ii)
         jj=1;
     else
         if jj==1
             peak(mm)=temp;
             index(mm)=p_index(ii-1);
             mm=mm+1;
         end
         jj=0;
     end
      temp=pmusic(ii);
 end
 if length(peak)<N
    [peak,in]=sort(peak);
    peak=fliplr(peak);
    in=fliplr(in);
    for zz=1:length(peak)
        out(zz)=index(in(zz));
    end 
    for zz=(length(peak)+1):N
        out(zz)=index(in(length(peak)));
    end 
 else
     [peak,in]=sort(peak);
    peak=fliplr(peak);
    in=fliplr(in);
    for zz=1:N
        out(zz)=index(in(zz));
    end 
    
end
[out,mm]=sort(out);