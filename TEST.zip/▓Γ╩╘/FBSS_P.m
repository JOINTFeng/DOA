clc;
clearvars;
close all;
set(0,'defaultfigurecolor','w')
 
tic;
%% 时域快拍信号采样
% -1- 参数配置
% 基本参数
N = 1024;       % 快拍点数
fs = 18e6;      % 系统采样率 单位：Hz
fc = 10e6;     % 载频       单位：Hz
c = 3e8;        % 光速       单位：m/s
lambda = c/fc;  % 波长       单位：m
 
% 信号 1 参数配置
B1 = 3e3;  % 信号1带宽 单位：Hz
T1 = N/fs;   % 信号1时宽 单位：s
K1 = B1/T1;  % 信号1调频斜率 单位：Hz/s
 
% 信号 2 参数配置
B2 = 6e3;  % 信号2带宽 单位：Hz
T2 = N/fs;   % 信号2时宽 单位：s
K2 = B2/T2;  % 信号2调频斜率 单位：Hz/s
 
 
% -2- 采样
t = (-N/2:N/2-1)/fs;        % 时间轴 
S1 = exp(1j*pi*K1*t.^2);    % 信号1采样 信源1 与信源2非相干
S2 = exp(1j*pi*K2*t.^2);    % 信号2采样 信源2 与信源1非相干
S = [S1;S1];       % 相干信号 信号矩阵 （前2个信号相干）
 
%COV_COEFF_S1S2 = abs(cov(S1,S2)); % 信源1与信源2的相关性验证 
 
%% 阵列期望信号构建
% -1- 目标参数配置
Targ_Num = 2;            % 目标个数
theta = [40,43];      % 波达角度 单位：° 设定范围：[0 360)
theta=sort(theta);  
MonteCarloNum=200;
% -2- 阵列参数配置
M =65;             % 阵元个数
%r = 7*lambda/pi;    % 圆阵半径 单位：m
r=lambda/(4*sin(pi/M));
% -3- 计算方向矩阵
A = zeros(M,Targ_Num);
for i = 1:Targ_Num
    A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
end
 
% -4- 无噪阵列信号
Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);
 
% -5- 加噪
%SNR=linspace(0,35,5);
% SNR=0:20; 
% for iii=1:length(SNR)
    for CarloNum=1:MonteCarloNum
%for iii=1:length(SNR) 
Array_n=awgn(Array,20,'measured');
%Rx=Array_n*Array_n'/N;

%% 基于MME算法+Root-MUSIC算法的DOA估计
% 主要参考文献[1]2.2节
% -STEP 1- 由式(4)对圆阵数据 X 进行模式空间变换得到 (2K+1) 维虚拟均匀线阵数据 Y
% 构建矩阵T
K = floor(2*pi*r/lambda);
%K = 5; 
W = exp(1j*2*pi*((-K:K).')/M*(0:M-1));
J_v = zeros(2*K+1,1);
for i = -K:K
    J_v(i+K+1) = besselj(i,2*pi*r/lambda)*((1j)^i);
end
J_ = diag(J_v);
T = (inv(J_))*W/M;
B = T*A;
%矩阵转换
Y = T*Array_n;
 


% %空间平滑矩阵
% m = 10;                     %每个子阵阵元数
% p = 2*K-m+2;                %子阵个数
% D = diag(exp((-1i*theta)));
% 
% R = zeros(m,m);
%     for jj = 1:p
%         X = B(1:10,:)*D^(jj-1)*S;
%         X = awgn(X,SNR(:,20),'measured');
%         R = R + X*X';
%     end;
% 
% Rf = R/N;                %前后向平滑接收数据矩阵
%     J = eye(m);    J = J(:,m:-1:1);  %反对角线置换矩阵
%     Rfb=(Rf+J*Rf.'*J)/2;             %前后向平滑接收数据矩阵
% [U_1,V_1] = eig(Rfb);
% U_w = U_1(:,1:m-3);
% 
% 
% theta1 = -180:0.1:180; %Peak search（峰值搜索）
% theta_search_step = 0.1;                 % 角度搜索步长 
% theta_search_range = [-180,180];            % 角度搜索区间
% theta_search = (theta_search_range(1) :...
%                 theta_search_step :...
%                 theta_search_range(2)); % 搜索的角度值
% a_theta = exp(1j*((0:K).').*(theta_search/180*pi));
% P_MUSIC = zeros(1,length(a_theta));
% for k = 1:length(P_MUSIC) 
%     P_MUSIC(k) = 1/((a_theta(:,k))'*(U_w*U_w')*a_theta(:,k));
% end
% figure(1);
% plot(theta_search,10*log10(abs(P_MUSIC)/max(abs(P_MUSIC))),'b-.')
% P_MUSIC= P_MUSIC';
% title('MGEVD')
% xlabel('Angle/(\circ)')
% ylabel('Spectrum/dB')
% xlim([-180,180]);


subarrayl=4;
subarrayn=2*K+2-4;
Rf=zeros(subarrayl,subarrayl);
Jb=zeros(subarrayl,subarrayl);
for  row_3=1:subarrayl
    Jb(row_3,subarrayl-(row_3-1))=1;
end; 
for  n=1:subarrayn
     yf_1{n}=Y(n:subarrayl+n-1,:);
     Rf_1{n}=1/N*yf_1{n}*yf_1{n}';
     Rf=Rf+Rf_1{n};
end;
Rf=Rf/subarrayn;                                       %前向平滑相关矩阵
Rb=Jb*conj(Rf)*Jb;                                     %后向平滑相关矩阵
Rfb=1/2*(Rf+Rb);  
%求空间谱函数
[U,R]=eig(Rfb);
for iiii=1:subarrayl                                        %对特征值进行排序并得噪声子空间
    b(iiii)=abs(R(iiii,iiii));
end
[c,e]=sort(b);
for iiii=1:subarrayl-3
    Un(:,iiii)=U(:,e(iiii));
end



the=[-180:0.1:180]*pi/180;
for nn=1:length(the)
    a=exp(j*[-3:1:0]'*(the(nn)));
    Ena=a'*Un;
    den=Ena*Ena';
    DOAU(nn)=1/den;
end




DOAU_S=20*log(abs(DOAU)/max(abs(DOAU)));
%画图
figure(1);
plot(the*180/pi,DOAU_S);
title('MODE SPACE-SMOOTH')
xlabel('Angle/(\circ)')
ylabel('Spectrum/dB')
xlim([-180,180]);
DOAs1 = [];
DOAU=DOAU';
 theta1 = -180:0.1:180; 
 %Peak search（峰值搜索）
    a = zeros(M, length(theta1));
    res = zeros(length(theta1), 1);
    [resSorted, orgInd] = sort(DOAU, 'descend');
    DOAs1 = ([orgInd(1:Targ_Num, 1)]-1801)/10;
    theta_doa=sort(DOAs1)
    %RSME(:,CarloNum)=(theta_doa-theta').^2
    %end


% est_music(:,CarloNum)=(abs(sort(peak_DML(P_MUSIC,theta1,Targ_Num))-theta)).^2;
%  suc_FBSS(iii,MonteCarloNum)=0;
%  if est_music(3,CarloNum)<1
%      suc_FBSS(iii,CarloNum)=suc_FBSS(iii,CarloNum)+1;   %成功概率
%  end
% 
    end
% RMSE(:,iii) = mean(est_music,2);
% end
% Probability_FBSS=mean(suc_FBSS,2)';
% RMSE1 = mean(RMSE);