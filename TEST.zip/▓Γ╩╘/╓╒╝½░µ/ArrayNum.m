s3=[0.0292562499999999 0.0688041666666670 0.101437500000000 0.184002499999999];
s4=[0.0471500000000003 0.105250000000000 0.182212500000000 0.240869999999999 ];
%我的算法
s5=[0.0198593631273821 0.0399324184290808 0.0695206375672345 0.163422499999999];
SNR=linspace(2,5,4);
figure;
s1=semilogy(SNR,s3,'-dm',SNR,s4,'-*b',SNR,s5,'-or');
xticks([2 3 4 5]);
% 获取当前的坐标轴
ax = gca;

% 设置图例字体大小为12点
legend_box = legend('MGEVD','MODE-TOEP','MERM');
set(legend_box, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置x轴标签字体大小为12点
xlabel('相干源数', 'FontName', '宋体', 'FontSize', 12);

% 设置y轴标签字体大小为12点
ylabel('RMSE/(°)', 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴刻度标签字体大小为12点
set(ax, 'XTickLabel', get(ax,'XTickLabel'), 'FontName', 'Times New Roman', 'FontSize', 12);
set(ax, 'YTickLabel', get(ax,'YTickLabel'), 'FontName', 'Times New Roman', 'FontSize', 12);