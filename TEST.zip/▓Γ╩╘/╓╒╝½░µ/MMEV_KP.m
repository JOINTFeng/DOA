%% CLEAR
clc;
clearvars;
close all;
set(0,'defaultfigurecolor','w')
 
tic;
%% 时域快拍信号采样
% -1- 参数配置
% 基本参数
N=20:20:300;
for iii=1:length(N)
fs = 18e8;      % 系统采样率 单位：Hz
fc = 10e6;     % 载频       单位：Hz
c = 3e8;        % 光速       单位：m/s
lambda = c/fc;  % 波长       单位：m
 
% 信号 1 参数配置
B1 = 3e3;  % 信号1带宽 单位：Hz
T1 = N(iii)/fs;   % 信号1时宽 单位：s
K1 = B1/T1;  % 信号1调频斜率 单位：Hz/s
 
% 信号 2 参数配置
B2 = 6e3;  % 信号2带宽 单位：Hz
T2 = N(iii)/fs;   % 信号2时宽 单位：s
K2 = B2/T2;  % 信号2调频斜率 单位：Hz/s
 
 
% -2- 采样
t = (-N(iii)/2:N(iii)/2-1)/fs;        % 时间轴 
S1 = exp(1j*pi*K1*t.^2);    % 信号1采样 信源1 与信源2非相干
S2 = exp(1j*pi*K2*t.^2);    % 信号2采样 信源2 与信源1非相干
S = [S1;S1;2*S2];       % 相干信号 信号矩阵 （前2个信号相干）
 
%% 阵列期望信号构建
% -1- 目标参数配置
Targ_Num = 3;            % 目标个数
theta = [-20,40,-120];      % 波达角度 单位：° 设定范围：[0 360)
theta=sort(theta)'; 
 
% -2- 阵列参数配置
M =19;             % 阵元个数
%r = 7*lambda/pi;    % 圆阵半径 单位：m
r=lambda/(4*sin(pi/M));
% -3- 计算方向矩阵
A = zeros(M,Targ_Num);
for i = 1:Targ_Num
    A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
end
 
% -4- 无噪阵列信号
Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);
 
% -5- 加噪
%SNR=linspace(5,35,5);
SNR=15; 
    for CarloNum=1:MonteCarloNum
Array_n=awgn(Array,SNR,'measured');
RXX=(Array_n*Array_n.')/N(iii);

[V,D]=eig(RXX);
[D,I]=sort(diag(D));
D=fliplr(D');
g=sum(D(Targ_Num+1:end))/(M-Targ_Num);



%% 基于MME算法+Root-MUSIC算法的DOA估计
% 主要参考文献[1]2.2节
% -STEP 1- 由式(4)对圆阵数据 X 进行模式空间变换得到 (2K+1) 维虚拟均匀线阵数据 Y
% 构建矩阵T
K = floor(2*pi*r/lambda);
%K = 5; 
W = exp(1j*2*pi*((-K:K).')/M*(0:M-1));
J_v = zeros(2*K+1,1);
for i = -K:K
    J_v(i+K+1) = besselj(i,2*pi*r/lambda)*((1j)^i);
end
J_ = diag(J_v);
T = (inv(J_))*W/M;
% 矩阵转换
Y = T*Array_n;
 
% -STEP 2- 根据式(7)求得变换后的数据 Y 的协方差矩阵 RYY
TM=T*T.';

RYY = Y*Y.'/N(iii);
RYY=RYY-g*g*eye(2*K+1,2*K+1)*TM;
% -STEP 3- 对 RYY 特征分解得到其最大特征矢量 v
% 对协方差矩阵进行特征值分解
[V,eigenvalue] = eig(RYY);        
% 特征值按降序排列
eigenvalue = diag(eigenvalue);                                  % 取特征值 转为列向量
[eigen_sort,eigen_index] = sort(abs(eigenvalue),'descend');     % 特征值降序排列
% 提取最大特征矢量v
v = V(:,eigen_index(1)); 
% -STEP 4- 根据式(8)构造新的矩阵 E
E = zeros(K+1,K+1);
for i = 1:K+1
    E(i,:) = v(K+i:-1:i);
end
 
% -STEP 5- 对 E 特征分解得到噪声子空间 UW
% 对 E 矩阵进行特征值分解
[V2,eigenvalue2] = eig(E);        
 
% 特征值按降序排列
eigenvalue2 = diag(eigenvalue2);                                   % 取特征值 转为列向量
[eigen_sort2,eigen_index2] = sort(abs(eigenvalue2),'descend');     % 特征值降序排列
D1 = Targ_Num;                                                     % 信源数目 
 
% 构造噪声子空间
Un = V2(:,eigen_index2(D1+1:end));
Gn = Un*Un';
%%%Root-MUSIC%%%
MM=2*K+1;
a = zeros(2*MM-1,1);
for j=-(MM-1):(MM-1)
a(MM+j) = sum( diag(Gn,j) );
end
ra=roots([a]);
rb=ra(abs(ra)<1);
% 选取最接近单位圆的n个根
[dumm,I]=sort(abs(abs(rb)-1));
degrad=pi/180;
w=angle(rb(I(1:D1))); 
fi=-w/degrad;
theta_doa(:,CarloNum)=(abs(sort(fi)-theta));
theta_doa1(:,CarloNum)=(abs(sort(fi)-theta)).^2;
suc_MMEV_RM(iii,MonteCarloNum)=0;
if theta_doa(2,CarloNum)<1
    suc_MMEV_RM(iii,CarloNum)=suc_MMEV_RM(iii,CarloNum)+1;   %成功概率
end

end
RMSE(:,iii) = mean(theta_doa1,2);
end

Probability_MMEV_RM=mean(suc_MMEV_RM,2)';
RMSE1 = mean(RMSE);
