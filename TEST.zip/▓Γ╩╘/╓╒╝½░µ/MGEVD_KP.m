clc;
clearvars;
close all;
set(0,'defaultfigurecolor','w')
 
tic;
%% 时域快拍信号采样
% -1- 参数配置
% 基本参数
N=20:20:300;
for iii=1:length(N)
fs = 18e6;      % 系统采样率 单位：Hz
fc = 10e6;     % 载频       单位：Hz
c = 3e8;        % 光速       单位：m/s
lambda = c/fc;  % 波长       单位：m
 
% 信号 1 参数配置
B1 = 3e3;  % 信号1带宽 单位：Hz
T1 = N(iii)/fs;   % 信号1时宽 单位：s
K1 = B1/T1;  % 信号1调频斜率 单位：Hz/s
 
% 信号 2 参数配置
B2 = 6e3;  % 信号2带宽 单位：Hz
T2 = N(iii)/fs;   % 信号2时宽 单位：s
K2 = B2/T2;  % 信号2调频斜率 单位：Hz/s
 
 
% -2- 采样
t = (-N(iii)/2:N(iii)/2-1)/fs;        % 时间轴 
S1 = exp(1j*pi*K1*t.^2);    % 信号1采样 信源1 与信源2非相干
S2 = exp(1j*pi*K2*t.^2);    % 信号2采样 信源2 与信源1非相干
S = [S1;S1;2*S2];       % 相干信号 信号矩阵 （前2个信号相干）
 
%COV_COEFF_S1S2 = abs(cov(S1,S2)); % 信源1与信源2的相关性验证 
 
%% 阵列期望信号构建
% -1- 目标参数配置
Targ_Num = 3;            % 目标个数
theta = [-20,40,-120];      % 波达角度 单位：° 设定范围：[0 360)
theta=sort(theta);  
MonteCarloNum=200;  
% -2- 阵列参数配置
M =19;             % 阵元个数
d_lambda = 1/2;     % 阵元间距/波长
%r = 7*lambda/pi;    % 圆阵半径 单位：m
r=lambda/(4*sin(pi/M));
% -3- 计算方向矩阵
A = zeros(M,Targ_Num);
for i = 1:Targ_Num
    A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
end
 
% -4- 无噪阵列信号
Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);
 
% -5- 加噪
%SNR=linspace(5,35,5);
SNR=15; 
    for CarloNum=1:MonteCarloNum
%for iii=1:length(SNR) 
Array_n=awgn(Array,SNR,'measured');

RXX=(Array_n*Array_n.')/N(iii);
[V,D]=eig(RXX);
[D,I]=sort(diag(D));
D=fliplr(D');
g=sum(D(Targ_Num+1:end))/(M-Targ_Num);

%% 基于MME算法+Root-MUSIC算法的DOA估计
% 主要参考文献[1]2.2节
% -STEP 1- 由式(4)对圆阵数据 X 进行模式空间变换得到 (2K+1) 维虚拟均匀线阵数据 Y
% 构建矩阵T
K = floor(2*pi*r/lambda);
%K = 5; 
W = exp(1j*2*pi*((-K:K).')/M*(0:M-1));
J_v = zeros(2*K+1,1);
for i = -K:K
    J_v(i+K+1) = besselj(i,2*pi*r/lambda)*((1j)^i);
end
J_ = diag(J_v);
T = (inv(J_))*W/M;
% 矩阵转换
Y = T*Array_n;
 
% -STEP 2- 根据式(7)求得变换后的数据 Y 的协方差矩阵 RYY

%RYY = (Y*Y'/N)-g*g*eye(2*K+1,2*K+1);
RYY = (Y*Y.'/N(iii));
[U,V]=eig(RYY,T*T.');
V = diag(V);                                   % 取特征值 转为列向量
[V_sort,V_index] = sort(abs(V),'descend');     % 特征值降序排列
U1 = U(:,V_index(1:Targ_Num));


Uls=T*T.'*U1;
Uls1=Uls(:,1);

X1 = zeros(K+1,K+1);
for i = 1:K+1
    X1(i,:) = Uls1(K+i:-1:i);
end

J1 = eye(K+1,K+1); % 生成单位矩阵
J1 = flip(J1); % 将矩阵上下翻转

Y=[X1,J1*conj(X1)];
R1 = Y*Y'; 

[V2,eigenvalue2] = eig(R1);        
 
% 特征值按降序排列
eigenvalue2 = diag(eigenvalue2);                                   % 取特征值 转为列向量
[eigen_sort2,eigen_index2] = sort(abs(eigenvalue2),'descend');     % 特征值降序排列
D1 = Targ_Num;                                                      % 信源数目 
 
% 构造噪声子空间
U_w = V2(:,eigen_index2(D1+1:end));



theta1 = -180:0.15:180; %Peak search（峰值搜索）
theta_search_step = 0.15;                 % 角度搜索步长 
theta_search_range = [-180,180];            % 角度搜索区间
theta_search = (theta_search_range(1) :...
                theta_search_step :...
                theta_search_range(2)); % 搜索的角度值
 
% 遍历搜索
a_theta = exp(1j*((0:K).').*(theta_search/180*pi));
P_MUSIC = zeros(1,length(a_theta));
for k = 1:length(P_MUSIC)
    P_MUSIC(k) = 1/((a_theta(:,k))'*(U_w*U_w')*a_theta(:,k));
end
% figure(1);
% plot(theta_search,10*log10(abs(P_MUSIC)/max(abs(P_MUSIC))),'b-.')
% P_MUSIC= P_MUSIC';
% title('MGEVD')
% xlabel('Angle/(\circ)')
% ylabel('Spectrum/dB')
% xlim([-180,180]);

DOAs1 = [];
 
%     a = zeros(M, length(theta1));
%     res = zeros(length(theta1), 1);
%     [resSorted, orgInd] = sort(DOAU, 'descend');
%     DOAs1 = ([orgInd(1:Targ_Num, 1)]-1801)/10;
%     theta_doa=sort(DOAs1)
    %RSME(:,CarloNum)=(theta_doa-theta').^2
    %end


est_MGEVD(:,CarloNum)=abs(sort(peak_DML( P_MUSIC,theta1,Targ_Num))-theta).^2;
est_MGEVD1(:,CarloNum)=abs(sort(peak_DML( P_MUSIC,theta1,Targ_Num))-theta);

suc_MGEVD(iii,MonteCarloNum)=0;
if est_MGEVD1(2,CarloNum)<1
    suc_MGEVD(iii,CarloNum)=suc_MGEVD(iii,CarloNum)+1;   %成功概率
end
    end
RMSE(:,iii) = mean(est_MGEVD,2);
end
Probability_MGEVD=mean(suc_MGEVD,2)';
RMSE1 = mean(RMSE);