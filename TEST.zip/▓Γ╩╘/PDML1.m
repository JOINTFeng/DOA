clc;
clearvars;
close all;
set(0,'defaultfigurecolor','w')
 
tic;
%% 时域快拍信号采样
% -1- 参数配置
% 基本参数
N = 512;       % 快拍点数
fs = 18e8;      % 系统采样率 单位：Hz
fc = 6e8;     % 载频       单位：Hz
c = 3e8;        % 光速       单位：m/s
lambda = c/fc;  % 波长       单位：m
 
% 信号 1 参数配置
B1 = 3e3;  % 信号1带宽 单位：Hz
T1 = N/fs;   % 信号1时宽 单位：s
K1 = B1/T1;  % 信号1调频斜率 单位：Hz/s
 
% 信号 2 参数配置
B2 = 100e3;  % 信号2带宽 单位：Hz
T2 = N/fs;   % 信号2时宽 单位：s
K2 = B2/T2;  % 信号2调频斜率 单位：Hz/s
 
 
% -2- 采样
t = (-N/2:N/2-1)/fs;        % 时间轴 
S1 = exp(1j*pi*K1*t.^2);    % 信号1采样 信源1 与信源2非相干
S2 = exp(1j*pi*K2*t.^2);    % 信号2采样 信源2 与信源1非相干
S = [S1;S1;S1];       % 相干信号 信号矩阵 （前2个信号相干）
 
%COV_COEFF_S1S2 = abs(cov(S1,S2)); % 信源1与信源2的相关性验证 
 
%% 阵列期望信号构建
% -1- 目标参数配置
Targ_Num = 3;            % 目标个数
theta = [-20,40,-120];      % 波达角度 单位：° 设定范围：[0 360)
theta=sort(theta);  
MonteCarloNum=200;  
% -2- 阵列参数配置
M =16;             % 阵元个数
%d_lambda = 1/2;     % 阵元间距/波长
%r = 7*lambda/pi;    % 圆阵半径 单位：m
r=lambda/(4*sin(pi/8));
% -3- 计算方向矩阵
A = zeros(M,Targ_Num);
for i = 1:Targ_Num
    A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
end
 
% -4- 无噪阵列信号
Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);
 
% -5- 加噪
%SNR=linspace(5,35,5);
%SNR=0:20; 
%for iii=1:length(SNR)
 for CarloNum=1:MonteCarloNum
%for iii=1:length(SNR) 
Array_n=awgn(Array,25,'measured');

%% 基于MME算法+Root-MUSIC算法的DOA估计
% 主要参考文献[1]2.2节
% -STEP 1- 由式(4)对圆阵数据 X 进行模式空间变换得到 (2K+1) 维虚拟均匀线阵数据 Y
% 构建矩阵T
%K = floor(2*pi*r/lambda);
K = 5; 
W = exp(1j*2*pi*((-K:K).')/M*(0:M-1));
J_v = zeros(2*K+1,1);
for i = -K:K
    J_v(i+K+1) = besselj(i,2*pi*r/lambda)*((1j)^i);
end
J_ = diag(J_v);
T = (inv(J_))*W/M;
% 矩阵转换
Y = T*Array_n;
 
% -STEP 2- 根据式(7)求得变换后的数据 Y 的协方差矩阵 RYY
RYY = Y*Y'/N;

[Vn,D] = eig(RYY);              %特征值分解，[Vn,D]=eig(Rxx)返回特征值的对角矩阵D和矩阵En，其列是对应的右特征向量，使得 Rx_j*Vn = Vn*D。
EVA = diag(D)';                  %EVA = diag(D) 返回包含主对角线上向量 D 的元素的对角矩阵。
[EVA,I] = sort(EVA);             %[EVB,I] = sort(EVA)还会为按升序对EVA的元素进行排序返回一个索引向量的集合。I的大小与EVA的大小相同，它描述了EVA的元素沿已排序的维度在EVB中的排列情况。例如，如果EVA是一个向量，则EVB=EVA(I)。
EVA = fliplr(EVA);               %左右反转，从大到小排序
Vn = fliplr(Vn(:,I));            %对应特征向量排序
Vn1=Vn(:,Targ_Num+1:2*K+1);               %噪声子空间


searching_doa=[-180:0.05:180]';
for i=1:length(searching_doa)
    A1 = exp(1j*((-K:K).')*(searching_doa(i)/180*pi));
    p=A1*pinv(A1'*A1)*A1';
    ang(i)=abs(sum(diag(p*RYY)));
    %est_DML=peak_DML(ang,theta1,Targ_Num);
end
% [t,k]=max(ang);
% k1=searching_doa(k)
figure(1);
plot(searching_doa,ang);
grid on;
% for i=1:length(searching_doa)
%     th=[k1,searching_doa(i)];
%     A1 = exp(1j*((-K:K).').*(th/180*pi));
%     p=A1*pinv(A1'*A1)*A1';
%     ang(i)=sum(diag(p*RYY));
% end
% [t,k]=max(ang);
% k2=searching_doa(k)
% th=sort([k1,k2]);
DOAs1 = [];
DOAU=ang';
theta1 = -180:0.05:180; %Peak search（峰值搜索）
est_DML(CarloNum,:)=peak_DML(DOAU,theta1,Targ_Num);
 end
est_DML=est_DML';