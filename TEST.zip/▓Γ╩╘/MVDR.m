clc;
clearvars;
close all;
set(0,'defaultfigurecolor','w')
 
tic;
%% 时域快拍信号采样
% -1- 参数配置
% 基本参数
N = 512;       % 快拍点数
fs = 18e8;      % 系统采样率 单位：Hz
fc = 6e8;     % 载频       单位：Hz
c = 3e8;        % 光速       单位：m/s
lambda = c/fc;  % 波长       单位：m
 
% 信号 1 参数配置
B1 = 3e3;  % 信号1带宽 单位：Hz
T1 = N/fs;   % 信号1时宽 单位：s
K1 = B1/T1;  % 信号1调频斜率 单位：Hz/s
 
% 信号 2 参数配置
B2 = 100e3;  % 信号2带宽 单位：Hz
T2 = N/fs;   % 信号2时宽 单位：s
K2 = B2/T2;  % 信号2调频斜率 单位：Hz/s
 
 
% -2- 采样
t = (-N/2:N/2-1)/fs;        % 时间轴 
S1 = exp(1j*pi*K1*t.^2);    % 信号1采样 信源1 与信源2非相干
S2 = exp(1j*pi*K2*t.^2);    % 信号2采样 信源2 与信源1非相干
S = [S1;S1];       % 相干信号 信号矩阵 （前2个信号相干）
 
%COV_COEFF_S1S2 = abs(cov(S1,S2)); % 信源1与信源2的相关性验证 
 
%% 阵列期望信号构建
% -1- 目标参数配置
Targ_Num = 2;            % 目标个数
theta = [40,43];      % 波达角度 单位：° 设定范围：[0 360)
theta=sort(theta);  
MonteCarloNum=5;  
% -2- 阵列参数配置
M =65;             % 阵元个数
d_lambda = 1/2;     % 阵元间距/波长
%r = 7*lambda/pi;    % 圆阵半径 单位：m
%r=lambda/(4*sin(pi/8));
r=lambda/(4*sin(pi/M));
% -3- 计算方向矩阵
A = zeros(M,Targ_Num);
for i = 1:Targ_Num
    A(:,i) = exp(1j*2*pi/lambda*r*cos(theta(i)/180*pi-((0:M-1).')*2*pi/M));
end
 
% -4- 无噪阵列信号
Array = A(:,1:Targ_Num)*S(1:Targ_Num,:);
 
% -5- 加噪
%SNR=linspace(5,35,5);
%SNR=0:20; 
%for iii=1:length(SNR)
    for CarloNum=1:MonteCarloNum
%for iii=1:length(SNR) 
Array_n=awgn(Array,20,'measured');
Rx=Array_n*Array_n'/N;

%% 基于MME算法+Root-MUSIC算法的DOA估计
% 主要参考文献[1]2.2节
% -STEP 1- 由式(4)对圆阵数据 X 进行模式空间变换得到 (2K+1) 维虚拟均匀线阵数据 Y
% 构建矩阵T
%K = floor(2*pi*r/lambda);
K = 5; 
W = exp(1j*2*pi*((-K:K).')/M*(0:M-1));
J_v = zeros(2*K+1,1);
for i = -K:K
    J_v(i+K+1) = besselj(i,2*pi*r/lambda)*((1j)^i);
end
J_ = diag(J_v);
T = (inv(J_))*W/M;
% 矩阵转换
Y = T*Array_n;
 
% -STEP 2- 根据式(7)求得变换后的数据 Y 的协方差矩阵 RYY

% J1=diag(ones(2*K+1,2*K+1));
% J1=diag(J1);
J1 = eye(2*K+1,2*K+1); % 生成单位矩阵
J1 = flip(J1); % 将矩阵上下翻转
Y=[Y,J1*conj(Y)];

%奇异值分解
% [U,S,V]=svd(Y);
% R1=U*U.'


R1 = inv(Y*Y'./2*N);   %这里需要是共轭转置！！
the=[-180:0.1:180]*pi/180;
searching_doa=[-180:0.1:180];
for ii = 1:length(searching_doa)
    A1 = exp(1j*((-K:K).').*(searching_doa(ii)/180*pi));
    caponresult1(ii) = 1/(abs(A1'*R1*A1));
end
caponresult1 = caponresult1;

% for nn=1:length(the)
%     a=exp(j*[-3:1:0]'*(the(nn)));
%     num=a'*a;
%     Ena=a'*Un;
%     den=Ena*Ena';
%     DOAU(nn)=1/den;
% end
% DOAU_S=20*log(abs(DOAU)/max(abs(DOAU)));
%画图
figure(1);
plot(searching_doa,caponresult1);
title('MODE MVDR')
xlabel('Angle/(\circ)')
ylabel('Spectrum/dB')
xlim([-180,180]);
DOAs1 = [];
caponresult1=caponresult1';
 theta1 = -180:0.1:180; %Peak search（峰值搜索）
%     a = zeros(M, length(theta1));
%     res = zeros(length(theta1), 1);
%     [resSorted, orgInd] = sort(DOAU, 'descend');
%     DOAs1 = ([orgInd(1:Targ_Num, 1)]-1801)/10;
%     theta_doa=sort(DOAs1)
    %RSME(:,CarloNum)=(theta_doa-theta').^2
    %end


est_music(CarloNum,:)=peak_DML(caponresult1,theta1,Targ_Num);
    end
est_music=est_music';